Creating a advanced POS system
faizan